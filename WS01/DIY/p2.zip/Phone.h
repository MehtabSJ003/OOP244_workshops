/*
Name - MEHTAB SINGH JAGDE
Student ID - 119003226
Email - mjagde@myseneca.ca
Section - ZEE
Date - 15 / 09 / 2023

I have completed all my assignments myself respecting academic integrity.

*/
#ifndef SDDS_PHONE_H 
#define SDDS_PHONE_H
namespace sdds {
    struct PhoneRecord {
        char name[51];
        char areaCode[4];
        char prefix[4];
        char number[5];
    };
	// runs the phone directory application
	void phoneDir(const char* programTitle, const char* fileName);
}
#endif