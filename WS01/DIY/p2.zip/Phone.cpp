/*
Name - MEHTAB SINGH JAGDE
Student ID - 119003226
Email - mjagde@myseneca.ca
Section - ZEE
Date - 15 / 09 / 2023

I have completed all my assignments myself respecting academic integrity.

*/
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include "Phone.h"
#include "cStrTools.h"
using namespace std;
namespace sdds {
	void phoneDir(const char* programTitle, const char* fileName) {
		cout << programTitle << " phone directory search " << endl;
		cout << "-------------------------------------------------------" << endl;
		char input[50];
		FILE* file = nullptr;
		do
		{
			cout << "Enter a partial name to search (no spaces) or enter '!' to exit" << endl;
			cout << "> ";
			cin.getline(input, 50);
			if (input[0] == '!')
			{
				break;
			}

			// Convert input to lowercase
			for (int i = 0; input[i] != '\0'; i++)
			{
				input[i] = toLower(input[i]);
			}

			file = fopen(fileName, "r");
			if (!file)
			{
				cout << fileName << " file not found! " << endl;
				break;
			}
			PhoneRecord pr;
			while (fscanf(file, "%[^\t]\t%s\t%s\t%s\n", pr.name, pr.areaCode, pr.prefix, pr.number) == 4)
			{
				// Convert pr.name to lowercase
				for (int i = 0; pr.name[i] != '\0'; i++)
				{
					pr.name[i] = tolower(pr.name[i]);
				}
				if (strStr(pr.name, input) != nullptr)
				{
					cout << pr.name << ": (" << pr.areaCode << ") " << pr.prefix << "-" << pr.number << endl;
				}
			}
			fclose(file);
		} while (true);
		cout << "Thank you for using " << programTitle << " directory. " << endl;
		if (file)
		{
			fclose(file);
		}
	}
}
